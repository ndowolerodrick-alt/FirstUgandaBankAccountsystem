# FirstBank Uganda Account System - User Guide

## 1. Introduction

Welcome to the FirstBank Uganda Account System! This desktop application allows you to create and manage various types of bank accounts. This guide will walk you through the process of using the application.

## 2. Getting Started

### 2.1 Launching the Application

After successfully installing and importing the project into NetBeans (refer to the `README.md` for installation instructions), you can launch the application by:

1.  Opening Apache NetBeans IDE.
2.  Navigating to the `FirstBankUgandaAccountSystem` project in the Projects tab.
3.  Clicking the green `Run Project` button (or pressing `F6`).

The main application window, titled "FirstBank Uganda Account System", will appear.

## 3. Creating a New Account

The main form allows you to input details for a new bank account. Follow the steps below to create an account:

### 3.1 Personal Information

*   **First Name**: Enter the account holder's first name. (Required, letters only, 2-30 characters)
*   **Last Name**: Enter the account holder's last name. (Required, letters only, 2-30 characters)
*   **National ID (NIN)**: Enter the 14-character National Identification Number. (Required, alphanumeric, uppercase only)
*   **Second NIN**: This field will only appear if you select "Joint" as the Account Type. Enter the second account holder's NIN. (Required for Joint accounts, alphanumeric, uppercase only)
*   **Email**: Enter a valid email address.
*   **Confirm Email**: Re-enter the email address to confirm. It must match the Email field.
*   **Phone Number**: Enter a valid Ugandan phone number in the format `+256XXXXXXXXX`.
*   **PIN**: Enter a 4-6 digit numeric PIN. Cannot be repeating digits (e.g., 0000, 1111).
*   **Confirm PIN**: Re-enter the PIN to confirm. It must match the PIN field.
*   **Date of Birth**: Select the Year, Month, and Day of birth using the dropdowns. The day dropdown will automatically adjust for the selected month and leap years. The age will be automatically calculated. (Must be between 18 and 75 years old. For Student accounts, age must be between 18 and 25).

### 3.2 Account Details

*   **Account Type**: Select the desired account type from the dropdown list (Savings, Current, Fixed Deposit, Student, Joint). This selection will determine the minimum deposit required and may show/hide the "Second NIN" field.
*   **Branch**: Select the desired branch from the dropdown list (Kampala, Gulu, Mbarara, Jinja, Mbale).
*   **Opening Deposit**: Enter the initial deposit amount. This must meet the minimum requirement for the selected account type:
    *   Savings: 50,000 UGX
    *   Current: 200,000 UGX
    *   Fixed Deposit: 1,000,000 UGX
    *   Student: 10,000 UGX
    *   Joint: 100,000 UGX

### 3.3 Submitting the Form

*   Click the `Submit` button to create the account.
*   If there are any validation errors, they will be displayed in red next to the respective fields, and a summary of errors will appear in a pop-up message.
*   If all validations pass, a success message will be displayed, and the account summary (including the newly generated account number) will appear in the "Account Summary is Below:" text area.

### 3.4 Resetting the Form

*   Click the `Reset` button to clear all input fields, reset dropdowns, and clear any error messages or the account summary.

## 4. Account Summary

Upon successful account creation, the "Account Summary is Below:" text area will display details of the new account, including:

*   Account Number
*   Account Holder's Name
*   Account Type
*   Branch
*   Date of Birth
*   Phone Number
*   Initial Deposit
*   Email
*   Second NIN (if applicable for Joint accounts)

## 5. Troubleshooting

*   **Validation Errors**: Carefully read the error messages displayed next to the fields and in the pop-up summary. Correct the invalid entries and try submitting again.
*   **Database Connection Issues**: Ensure that the `FirstBank.accdb` file is not open in another application and that all UCanAccess JAR files are correctly placed in the `lib` directory.

For further assistance, please refer to the `DeveloperGuide.pdf` or contact support. 
support.
