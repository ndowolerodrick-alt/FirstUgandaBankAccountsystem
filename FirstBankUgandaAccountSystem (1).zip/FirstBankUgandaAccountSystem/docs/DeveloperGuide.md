# FirstBank Uganda Account System - Developer Guide

## 1. Introduction

This document provides a technical overview of the FirstBank Uganda Account System, a Java Swing desktop application. It is intended for developers who wish to understand, maintain, or extend the application.

## 2. Project Structure

The project follows a standard NetBeans project structure with a clear separation of concerns:

```
FirstBankUgandaAccountSystem/
├── nbproject/                  # NetBeans project metadata
├── build.xml                   # Apache Ant build script
├── manifest.mf                 # JAR manifest file
├── src/                        # Source code root
│   ├── bank/                   # Base package
│   │   ├── database/           # Database connection and DAO classes
│   │   │   ├── AccountDAO.java
│   │   │   └── DatabaseConnection.java
│   │   ├── gui/                # GUI related classes (Swing forms)
│   │   │   └── MainForm.java
│   │   ├── model/              # Business logic and data models
│   │   │   ├── Account.java
│   │   │   ├── CurrentAccount.java
│   │   │   ├── FixedDepositAccount.java
│   │   │   ├── JointAccount.java
│   │   │   ├── SavingsAccount.java
│   │   │   └── StudentAccount.java
│   │   ├── util/               # Utility classes (e.g., account number generation)
│   │   │   └── AccountNumberGenerator.java
│   │   └── validation/         # Input validation logic
│   │       └── Validator.java
│   └── Main.java               # Main application entry point
├── lib/                        # External libraries (JARs)
│   ├── ucanaccess-5.0.1.jar
│   ├── hsqldb-2.5.0.jar
│   ├── jackcess-3.0.1.jar
│   ├── commons-logging-1.2.jar
│   └── commons-lang3-3.8.1.jar
├── database/                   # MS Access database file
│   └── FirstBank.accdb
├── README.md                   # Project README
├── screenshots/                # Placeholder for application screenshots
└── docs/                       # Project documentation
    ├── UserGuide.md
    └── DeveloperGuide.md
```

## 3. Key Components and Their Responsibilities

### 3.1 `bank.model` Package

This package contains the core business objects representing different account types.

*   **`Account.java`**: An abstract class defining common attributes (firstName, lastName, nin, email, phone, dob, branch, deposit, accountNumber) and an abstract method `minimumDeposit()`. It enforces polymorphism for account-specific minimum deposit rules.
*   **`SavingsAccount.java`, `CurrentAccount.java`, `FixedDepositAccount.java`, `StudentAccount.java`, `JointAccount.java`**: Concrete implementations of the `Account` class, each overriding `minimumDeposit()` to return their specific minimum deposit requirements. `JointAccount` includes an additional `secondNin` field.

### 3.2 `bank.validation` Package

This package handles all input validation logic.

*   **`Validator.java`**: A static utility class providing methods for validating various input fields such as names, NIN, email, phone numbers, PINs, and age. It ensures data integrity before processing.

### 3.3 `bank.util` Package

Contains general utility functions.

*   **`AccountNumberGenerator.java`**: A static utility class responsible for generating unique account numbers based on branch codes and the current year, with an auto-incrementing counter.

### 3.4 `bank.database` Package

Manages database connectivity and data access operations.

*   **`DatabaseConnection.java`**: Handles establishing a connection to the MS Access database (`FirstBank.accdb`) using the UCanAccess JDBC driver. It also includes a method to automatically create the `Accounts` table if it doesn't exist, defining its schema.
*   **`AccountDAO.java`**: (Data Access Object) Provides methods for interacting with the `Accounts` table in the database, specifically for adding new account records. It maps `Account` objects to database entries.

### 3.5 `bank.gui` Package

Contains the graphical user interface components.

*   **`MainForm.java`**: The main Swing JFrame for the application. It includes all the input fields, combo boxes, buttons, and a text area for displaying account summaries. It manages user interactions, triggers validation, and orchestrates account creation and persistence.

### 3.6 `bank.Main.java`

The application's entry point. It initializes the database connection (ensuring the table exists) and launches the `MainForm` on the Event Dispatch Thread (EDT) for Swing applications.

## 4. Database Schema

The `FirstBank.accdb` database contains a single table named `Accounts` with the following schema:

| Column Name     | Data Type      | Description                                     |
| :-------------- | :------------- | :---------------------------------------------- |
| `ID`            | `COUNTER`      | Primary Key, auto-incrementing                  |
| `AccountNumber` | `VARCHAR(255)` | Unique account number (e.g., KLA-2026-000001) |
| `FirstName`     | `VARCHAR(255)` | Account holder's first name                     |
| `LastName`      | `VARCHAR(255)` | Account holder's last name                      |
| `NIN`           | `VARCHAR(255)` | National Identification Number                  |
| `SecondNIN`     | `VARCHAR(255)` | Second NIN for joint accounts (nullable)        |
| `Email`         | `VARCHAR(255)` | Email address                                   |
| `Phone`         | `VARCHAR(255)` | Phone number                                    |
| `DOB`           | `DATE`         | Date of Birth                                   |
| `Age`           | `INTEGER`      | Calculated age                                  |
| `AccountType`   | `VARCHAR(255)` | Type of account (e.g., Savings, Current)        |
| `Branch`        | `VARCHAR(255)` | Bank branch                                     |
| `Deposit`       | `DOUBLE`       | Initial deposit amount                          |
| `PIN`           | `VARCHAR(255)` | Account PIN (stored as placeholder for now)     |
| `DateCreated`   | `DATE`         | Date the account was created                    |

## 5. Build Process

The project uses Apache Ant for building. The `build.xml` script defines targets for:

*   `init`: Creates necessary build directories.
*   `clean`: Removes compiled classes and distribution files.
*   `compile`: Compiles Java source files.
*   `jar`: Creates an executable JAR file, including all necessary UCanAccess dependencies.
*   `run`: Executes the compiled JAR file.
*   `dist`: Creates a distribution package with the JAR and `lib` folder.

## 6. External Dependencies

The following external JAR libraries are used and located in the `lib/` directory:

*   `ucanaccess-5.0.1.jar`: The UCanAccess JDBC driver for MS Access.
*   `hsqldb-2.5.0.jar`: A dependency of UCanAccess.
*   `jackcess-3.0.1.jar`: A dependency of UCanAccess for reading/writing Access databases.
*   `commons-logging-1.2.jar`: A common logging utility, dependency of UCanAccess.
*   `commons-lang3-3.8.1.jar`: Apache Commons Lang, provides helper utilities, dependency of UCanAccess.

## 7. Exception Handling

Exceptions are handled at various layers of the application:

*   **GUI Layer**: User-friendly error messages are displayed using `JOptionPane` for validation failures and unexpected runtime errors.
*   **Database Layer**: `SQLException`s are caught and reported, ensuring proper closing of database resources (connections, statements).

## 8. Extending the Application

Developers can extend the application by:

*   Adding new account types by creating new subclasses of `Account`.
*   Implementing new validation rules in the `Validator` class.
*   Adding new database operations in `AccountDAO`.
*   Enhancing the GUI with new features or improving existing ones in `MainForm`.

## 9. Future Enhancements

*   Implement user authentication and login.
*   Add functionality for viewing, updating, and deleting accounts.
*   Integrate reporting features.
*   Improve PIN storage security (e.g., hashing).
*   Migrate to a more robust database system (e.g., MySQL, PostgreSQL) for production environments.
