package bank;

import bank.database.DatabaseConnection;
import bank.gui.MainForm;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Ensure the database table exists
        DatabaseConnection.createTableIfNotExists();

        // Run the GUI on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            MainForm form = new MainForm();
            form.setVisible(true);
        });
    }
}
