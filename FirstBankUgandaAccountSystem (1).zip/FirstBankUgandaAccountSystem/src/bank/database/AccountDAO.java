package bank.database;

import bank.model.Account;
import bank.model.JointAccount;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AccountDAO {

    public void addAccount(Account account) throws SQLException {
        String sql = "INSERT INTO Accounts (AccountNumber, FirstName, LastName, NIN, SecondNIN, Email, Phone, DOB, Age, AccountType, Branch, Deposit, PIN, DateCreated) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, account.getAccountNumber());
            pstmt.setString(2, account.getFirstName());
            pstmt.setString(3, account.getLastName());
            pstmt.setString(4, account.getNin());
            
            if (account instanceof JointAccount) {
                pstmt.setString(5, ((JointAccount) account).getSecondNin());
            } else {
                pstmt.setString(5, null);
            }

            pstmt.setString(6, account.getEmail());
            pstmt.setString(7, account.getPhone());
            pstmt.setDate(8, Date.valueOf(account.getDob()));
            pstmt.setInt(9, bank.validation.Validator.calculateAge(account.getDob()));
            pstmt.setString(10, account.getClass().getSimpleName());
            pstmt.setString(11, account.getBranch());
            pstmt.setDouble(12, account.getDeposit());
            // PIN is not stored in Account object, so we need to pass it separately or retrieve it.
            // For now, let's assume PIN is handled by the GUI and not directly part of the Account model for persistence.
            // This needs to be clarified in requirements or passed as a parameter.
            // For demonstration, we'll use a placeholder or assume it's set in the Account object if needed.
            pstmt.setString(13, "****"); // Placeholder for PIN
            pstmt.setDate(14, Date.valueOf(java.time.LocalDate.now()));

            pstmt.executeUpdate();
        }
    }
}
