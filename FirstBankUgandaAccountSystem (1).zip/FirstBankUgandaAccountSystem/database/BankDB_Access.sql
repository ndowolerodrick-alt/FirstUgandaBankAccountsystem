-- ============================================================
-- BankDB - MS Access SQL Script
-- Run this in Access: Database Tools > Run Macro / Query Editor
-- Or use: File > Get External Data > Import > paste in query
-- ============================================================

CREATE TABLE Accounts (
    ID AUTOINCREMENT CONSTRAINT PK_Accounts PRIMARY KEY,
    AccountNumber TEXT(50)  CONSTRAINT UQ_AccountNumber UNIQUE,
    FirstName     TEXT(100),
    LastName      TEXT(100),
    NIN           TEXT(50),
    SecondNIN     TEXT(50),
    Email         TEXT(255),
    Phone         TEXT(20),
    DOB           DATETIME,
    Age           INTEGER,
    AccountType   TEXT(50),
    Branch        TEXT(100),
    Deposit       DOUBLE,
    PIN           TEXT(10),
    DateCreated   DATETIME DEFAULT NOW()
);
