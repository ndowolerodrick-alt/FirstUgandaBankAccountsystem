# FirstBankUgandaAccountSystem

This is a Java Swing desktop application for managing bank accounts, developed as a NetBeans project.

## Project Requirements

This application implements the following features:

*   **Object-Oriented Design**: Includes an abstract `Account` class with subclasses for different account types (Savings, Current, Fixed Deposit, Student, Joint).
*   **GUI**: A professional banking form for creating new accounts.
*   **Validation**: Comprehensive input validation for all fields.
*   **Account Number Generation**: Automatic generation of account numbers with a specific format.
*   **Database Integration**: Uses MS Access (`.accdb`) with UCanAccess JDBC Driver to store account information.
*   **Exception Handling**: Proper handling of exceptions with user-friendly messages.
*   **Code Quality**: Adherence to OOP principles (encapsulation, inheritance, abstraction, polymorphism) and commented important methods.

## Technologies Used

*   Java Swing
*   JDBC
*   MS Access (.accdb)
*   UCanAccess JDBC Driver

## Installation

1.  **Prerequisites**:
    *   Apache NetBeans IDE 25+ (or compatible version)
    *   JDK 17 or newer

2.  **Download Project**: Download the project ZIP file.

3.  **Extract**: Extract the contents of the ZIP file to your desired location.

4.  **Import into NetBeans**:
    *   Open Apache NetBeans IDE.
    *   Go to `File` -> `Open Project`.
    *   Navigate to the extracted project folder (`FirstBankUgandaAccountSystem`) and select it.
    *   Click `Open Project`.

5.  **Database Setup**:
    *   The application is designed to automatically create the `FirstBank.accdb` database file and the `Accounts` table within the `database/` directory if they do not exist.
    *   Ensure the `lib` folder contains all necessary UCanAccess and its dependencies JAR files.

## Running the Application

1.  In NetBeans, open the `FirstBankUgandaAccountSystem` project.
2.  Click the `Run Project` button (green play icon) or press `F6`.
3.  The main application window (`MainForm`) will appear.

## Usage

*   Fill in the required fields in the form.
*   Select the Account Type and Branch.
*   The `Second NIN` field will appear if `Joint` account type is selected.
*   Click `Submit` to create the account. Validation errors will be displayed if any.
*   Click `Reset` to clear all fields.
*   Account summary will be displayed in the text area upon successful submission.

## Project Structure

```
FirstBankUgandaAccountSystem/
├── nbproject/
├── build.xml
├── manifest.mf
├── src/
│   ├── bank/
│   │   ├── database/
│   │   │   ├── AccountDAO.java
│   │   │   └── DatabaseConnection.java
│   │   ├── gui/
│   │   │   └── MainForm.java
│   │   ├── model/
│   │   │   ├── Account.java
│   │   │   ├── CurrentAccount.java
│   │   │   ├── FixedDepositAccount.java
│   │   │   ├── JointAccount.java
│   │   │   ├── SavingsAccount.java
│   │   │   └── StudentAccount.java
│   │   ├── util/
│   │   │   └── AccountNumberGenerator.java
│   │   └── validation/
│   │       └── Validator.java
│   └── Main.java
├── lib/
│   ├── ucanaccess-5.0.1.jar
│   ├── hsqldb-2.5.0.jar
│   ├── jackcess-3.0.1.jar
│   ├── commons-logging-1.2.jar
│   └── commons-lang3-3.8.1.jar
├── database/
│   └── FirstBank.accdb (will be created automatically)
├── README.md
├── screenshots/
└── docs/
```
